BOT DE EMPLEOS - PRIMERA VERSION

Contenido:
- main.py: menú principal.
- database.py: base de datos SQLite.
- buscador.py: registro y procesamiento de publicaciones.
- filtros.py: filtro por ubicación y clasificación.
- postulaciones.py: preparación de mensajes para revisión.
- config.py: ubicaciones y palabras clave.
- validacion.py: validación básica de campos y enlaces.
- seguridad.py: detección básica de señales sospechosas.
- fuentes.py: punto de conexión para fuentes autorizadas.
- exportar.py: exportación CSV.
- requirements.txt: dependencias.

IMPORTANTE:
La búsqueda automática en LinkedIn e Instagram todavía no está conectada.
No se envían postulaciones automáticamente.

Para ejecutar, desde esta carpeta:
python3 main.py

La base de datos empleos.db se creará automáticamente al iniciar.
