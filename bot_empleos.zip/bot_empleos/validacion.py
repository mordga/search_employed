from urllib.parse import urlparse


def validar_oferta(oferta):
    campos = ["puesto", "ubicacion", "enlace", "fuente"]

    for campo in campos:
        if not str(oferta.get(campo, "")).strip():
            return False, f"Falta el campo: {campo}"

    url = urlparse(oferta["enlace"].strip())

    if url.scheme not in ("http", "https"):
        return False, "El enlace debe comenzar con http o https."

    if not url.netloc:
        return False, "El enlace no contiene un dominio válido."

    return True, "Oferta válida."
