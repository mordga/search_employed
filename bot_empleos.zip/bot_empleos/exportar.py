import csv
from database import obtener_ofertas


def exportar_ofertas():
    ofertas = obtener_ofertas()

    if not ofertas:
        print("No hay ofertas para exportar.")
        return

    with open(
        "ofertas.csv",
        "w",
        newline="",
        encoding="utf-8-sig"
    ) as archivo:
        escritor = csv.writer(archivo)
        escritor.writerow([
            "ID", "Puesto", "Empresa", "Ubicación",
            "Salario", "Horario", "Requisitos",
            "Enlace", "Fuente", "Fecha", "Estado"
        ])
        escritor.writerows(ofertas)

    print("Archivo ofertas.csv creado correctamente.")
