from database import inicializar_db, obtener_ofertas, guardar_oferta
from buscador import buscar_ofertas
from postulaciones import preparar_postulacion
from exportar import exportar_ofertas
from fuentes import mostrar_fuentes
from validacion import validar_oferta
from seguridad import analizar_seguridad


def mostrar_ofertas():
    ofertas = obtener_ofertas()

    if not ofertas:
        print("\nTodavía no hay ofertas registradas.")
        return

    for oferta in ofertas:
        print("\n----------------------------")
        print("ID:", oferta[0])
        print("Puesto:", oferta[1])
        print("Empresa:", oferta[2])
        print("Ubicación:", oferta[3])
        print("Salario:", oferta[4] or "No especificado")
        print("Horario:", oferta[5] or "No especificado")
        print("Requisitos:", oferta[6] or "No especificados")
        print("Enlace:", oferta[7])
        print("Fuente:", oferta[8])
        print("Estado:", oferta[10])


def agregar_oferta():
    print("\nREGISTRAR NUEVA OFERTA")

    oferta = {
        "puesto": input("Puesto: ").strip(),
        "empresa": input("Empresa: ").strip(),
        "ubicacion": input("Ubicación: ").strip(),
        "salario": input("Salario: ").strip(),
        "horario": input("Horario: ").strip(),
        "requisitos": input("Requisitos: ").strip(),
        "enlace": input("Enlace: ").strip(),
        "fuente": input("Fuente: ").strip()
    }

    valida, mensaje = validar_oferta(oferta)
    if not valida:
        print(mensaje)
        return

    alertas = analizar_seguridad(oferta)
    estado = "Revisión necesaria" if alertas else "Pendiente"

    if alertas:
        print("\nSe encontraron posibles señales de alerta:")
        for alerta in alertas:
            print("-", alerta)

    if guardar_oferta(oferta, estado):
        print("\nOferta registrada correctamente.")
        print("Estado:", estado)
    else:
        print("\nNo se pudo registrar. Comprueba si el enlace ya existe.")


def menu():
    inicializar_db()

    while True:
        print("""
================================
          BOT DE EMPLEOS
================================

1. Buscar ofertas
2. Ver ofertas registradas
3. Agregar una oferta
4. Preparar una postulación
5. Exportar ofertas a CSV
6. Consultar fuentes
7. Salir
""")

        opcion = input("Selecciona una opción: ").strip()

        if opcion == "1":
            buscar_ofertas()
        elif opcion == "2":
            mostrar_ofertas()
        elif opcion == "3":
            agregar_oferta()
        elif opcion == "4":
            try:
                oferta_id = int(input("ID de la oferta: "))
                preparar_postulacion(oferta_id)
            except ValueError:
                print("Introduce un ID válido.")
        elif opcion == "5":
            exportar_ofertas()
        elif opcion == "6":
            mostrar_fuentes()
        elif opcion == "7":
            print("Cerrando el bot...")
            break
        else:
            print("Opción no válida.")


if __name__ == "__main__":
    menu()
