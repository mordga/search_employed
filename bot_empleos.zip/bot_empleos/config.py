UBICACIONES = [
    "santa cruz de la sierra",
    "valle sanchez",
    "valle sánchez"
]

PALABRAS_CLAVE = [
    "sin experiencia",
    "atencion al cliente",
    "atención al cliente",
    "ayudante",
    "auxiliar",
    "medio tiempo",
    "aprendiz",
    "asistente",
    "repositor",
    "cajero"
]
