def obtener_publicaciones():
    """
    Punto de conexión para fuentes autorizadas.
    Por ahora no descarga publicaciones externas.
    """
    return []


def mostrar_fuentes():
    print("\nFUENTES DEL BUSCADOR")
    print("- LinkedIn: integración pendiente.")
    print("- Instagram: integración pendiente.")
    print("- Otras fuentes autorizadas: pendientes.")
