from database import guardar_oferta
from filtros import filtrar_ofertas, clasificar_oferta
from fuentes import obtener_publicaciones
from validacion import validar_oferta
from seguridad import analizar_seguridad


def registrar_publicaciones(publicaciones):
    nuevas = 0

    for oferta in filtrar_ofertas(publicaciones):
        valida, mensaje = validar_oferta(oferta)

        if not valida:
            print(mensaje)
            continue

        alertas = analizar_seguridad(oferta)
        estado = "Revisión necesaria" if alertas else "Pendiente"

        if alertas:
            print("\nOferta marcada para revisión:")
            for alerta in alertas:
                print("-", alerta)

        if guardar_oferta(oferta, estado):
            nuevas += 1

        etiquetas = clasificar_oferta(oferta)
        if etiquetas:
            print("Categorías:", ", ".join(etiquetas))

    return nuevas


def buscar_ofertas():
    print("\nBuscando publicaciones...")
    publicaciones = obtener_publicaciones()
    nuevas = registrar_publicaciones(publicaciones)

    print(f"\nNuevas ofertas registradas: {nuevas}")

    if not publicaciones:
        print("Todavía no hay fuentes externas conectadas.")
