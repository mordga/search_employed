FRASES_SOSPECHOSAS = [
    "paga para conseguir el empleo",
    "deposito para ingresar",
    "depósito para ingresar",
    "envia tu contraseña",
    "envía tu contraseña",
    "garantizamos ganancias",
    "paga por adelantado",
    "compra el material obligatorio antes de ingresar"
]


def analizar_seguridad(oferta):
    texto = " ".join(
        str(valor) for valor in oferta.values()
    ).lower()

    alertas = []

    for frase in FRASES_SOSPECHOSAS:
        if frase.lower() in texto:
            alertas.append(f"Señal de alerta: {frase}")

    return alertas
