import sqlite3

DB_NAME = "empleos.db"


def conectar():
    db = sqlite3.connect(DB_NAME)
    db.execute("PRAGMA foreign_keys = ON")
    return db


def inicializar_db():
    with conectar() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS ofertas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                puesto TEXT NOT NULL,
                empresa TEXT,
                ubicacion TEXT NOT NULL,
                salario TEXT,
                horario TEXT,
                requisitos TEXT,
                enlace TEXT UNIQUE NOT NULL,
                fuente TEXT NOT NULL,
                fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                estado TEXT DEFAULT 'Pendiente'
            )
        """)

        db.execute("""
            CREATE TABLE IF NOT EXISTS postulaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                oferta_id INTEGER NOT NULL,
                mensaje TEXT NOT NULL,
                estado TEXT DEFAULT 'Por revisar',
                fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (oferta_id)
                REFERENCES ofertas(id)
            )
        """)


def guardar_oferta(oferta, estado="Pendiente"):
    try:
        with conectar() as db:
            db.execute("""
                INSERT INTO ofertas (
                    puesto, empresa, ubicacion, salario,
                    horario, requisitos, enlace, fuente, estado
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                oferta["puesto"],
                oferta.get("empresa", ""),
                oferta["ubicacion"],
                oferta.get("salario", ""),
                oferta.get("horario", ""),
                oferta.get("requisitos", ""),
                oferta["enlace"],
                oferta["fuente"],
                estado
            ))
        return True
    except sqlite3.IntegrityError:
        return False


def obtener_ofertas():
    with conectar() as db:
        return db.execute("""
            SELECT * FROM ofertas
            ORDER BY fecha_registro DESC
        """).fetchall()


def obtener_oferta(oferta_id):
    with conectar() as db:
        return db.execute("""
            SELECT * FROM ofertas WHERE id = ?
        """, (oferta_id,)).fetchone()


def guardar_postulacion(oferta_id, mensaje):
    with conectar() as db:
        db.execute("""
            INSERT INTO postulaciones (oferta_id, mensaje)
            VALUES (?, ?)
        """, (oferta_id, mensaje))
