from database import obtener_oferta, guardar_postulacion


def preparar_postulacion(oferta_id):
    oferta = obtener_oferta(oferta_id)

    if not oferta:
        print("No se encontró esa oferta.")
        return

    print("\nOFERTA SELECCIONADA")
    print("Puesto:", oferta[1])
    print("Empresa:", oferta[2])
    print("Ubicación:", oferta[3])
    print("Enlace:", oferta[7])
    print("Estado:", oferta[10])

    if oferta[10] == "Revisión necesaria":
        print("\nEsta oferta tiene señales de alerta.")
        print("Verifícala por una fuente independiente antes de continuar.")
        return

    print("\nComprueba los requisitos, la edad permitida,")
    print("el horario y las condiciones laborales.")
    print("Si eres menor de edad, consulta con un adulto de confianza.")

    confirmar = input(
        "\n¿Has revisado la oferta y quieres preparar un mensaje? (s/n): "
    ).strip().lower()

    if confirmar != "s":
        print("Operación cancelada.")
        return

    mensaje = (
        f"Hola, estoy interesado/a en la vacante de {oferta[1]}. "
        "¿Podrían brindarme más información sobre los requisitos "
        "y las condiciones del puesto?"
    )

    print("\nMENSAJE PREPARADO:")
    print(mensaje)

    guardar = input(
        "\n¿Quieres guardar este mensaje para revisarlo? (s/n): "
    ).strip().lower()

    if guardar == "s":
        guardar_postulacion(oferta_id, mensaje)
        print("Mensaje guardado. No se ha enviado.")
    else:
        print("Mensaje descartado. No se ha enviado.")
