import unicodedata
from config import UBICACIONES, PALABRAS_CLAVE


def normalizar(texto):
    texto = str(texto or "").lower().strip()
    texto = unicodedata.normalize("NFD", texto)
    return "".join(
        caracter for caracter in texto
        if unicodedata.category(caracter) != "Mn"
    )


def filtrar_ofertas(ofertas):
    resultados = []
    ubicaciones = [normalizar(zona) for zona in UBICACIONES]

    for oferta in ofertas:
        ubicacion = normalizar(oferta.get("ubicacion", ""))

        if any(zona in ubicacion for zona in ubicaciones):
            resultados.append(oferta)

    return resultados


def clasificar_oferta(oferta):
    texto = normalizar(
        oferta.get("puesto", "") + " " +
        oferta.get("requisitos", "")
    )

    return [
        palabra
        for palabra in PALABRAS_CLAVE
        if normalizar(palabra) in texto
    ]
